import logging
import threading
import time

logger = logging.getLogger(__name__)


class MetaResearchAI:

    """
    Self-optimizing research controller
    """

    def __init__(self, router):

        self.router = router
        self.running = False

    def start(self):

        if self.running:
            return

        self.running = True

        thread = threading.Thread(
            target=self._loop,
            daemon=True
        )

        thread.start()

        logger.info("MetaResearchAI started")

    def _loop(self):

        while self.running:

            try:

                self._optimize_research()

            except Exception as e:

                logger.warning(f"MetaResearchAI error: {e}")

            time.sleep(60)

    def _optimize_research(self):

        grid = getattr(self.router, "research_grid", None)

        if not grid:
            return

        results = grid.top_results(20)

        if not results:
            return

        logger.info(
            f"MetaResearchAI analyzing {len(results)} research results"
        )

        best = results[0]

        if best.get("fitness", 0) > 0.5:

            logger.info("MetaResearchAI promoting strategy")

            genome_lib = getattr(self.router, "genome_library", None)

            if genome_lib:

                genome_lib.store_record(best)