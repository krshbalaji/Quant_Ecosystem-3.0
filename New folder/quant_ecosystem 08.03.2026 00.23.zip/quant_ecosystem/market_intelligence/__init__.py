"""Market intelligence layer package."""
