import logging
import importlib
import pkgutil
from pathlib import Path

logger = logging.getLogger(__name__)


class StrategyRegistry:

    def __init__(self, strategy_path="quant_ecosystem.strategies"):
        self.strategy_path = strategy_path
        self._strategies = {}

    # ----------------------------------------------------
    # PUBLIC API
    # ----------------------------------------------------

    def load(self):
        """
        Discover and load strategies automatically.
        """
        if self._strategies:
            return self._strategies

        logger.info("Discovering strategies...")

        try:
            package = importlib.import_module(self.strategy_path)
        except Exception as e:
            logger.error(f"Strategy package import failed: {e}")
            return {}

        for _, module_name, _ in pkgutil.walk_packages(package.__path__, package.__name__ + "."):

            try:
                module = importlib.import_module(module_name)
            except Exception as e:
                logger.warning(f"Strategy module load failed {module_name}: {e}")
                continue

            for attr in dir(module):

                obj = getattr(module, attr)

                if callable(obj) and getattr(obj, "IS_STRATEGY", False):

                    strategy_name = obj.__name__

                    self._strategies[strategy_name] = obj

                    logger.info(f"Strategy registered: {strategy_name}")

        logger.info(f"{len(self._strategies)} strategies loaded")

        return self._strategies

    # ----------------------------------------------------

    def register(self, name, strategy_callable):
        self._strategies[name] = strategy_callable

    # ----------------------------------------------------

    def get(self, name):
        return self._strategies.get(name)

    # ----------------------------------------------------

    def all(self):
        return self._strategies