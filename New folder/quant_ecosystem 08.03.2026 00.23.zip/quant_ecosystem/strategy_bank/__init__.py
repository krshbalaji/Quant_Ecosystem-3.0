"""Strategy bank layer package."""
