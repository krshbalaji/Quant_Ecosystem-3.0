"""
data_router.py — Quant Ecosystem 3.0
======================================

Unified market-data router for the ecosystem.

Architecture
------------
Each live or historical data source is encapsulated in an *adapter*
that implements the ``_FeedAdapter`` protocol::

    class _FeedAdapter:
        def get_candles(symbol, timeframe) -> List[Dict]
        def get_quote(symbol)             -> Dict
        def subscribe(symbol)             -> None
        def historical(symbol, start, end)-> List[Dict]

``DataRouter`` holds an ordered list of adapters (primary → fallbacks)
and delegates every call down the chain until one succeeds.  The final
fallback is always ``_SyntheticAdapter``, which generates deterministic
OHLCV series from a seeded PRNG so the system boots and runs end-to-end
in PAPER mode without any external services.

Supported adapters (all lazy-imported)
---------------------------------------
- ``_FyersAdapter``      — wraps quant_ecosystem.broker.fyers_broker
- ``_ZerodhaAdapter``    — wraps kiteconnect.KiteConnect
- ``_BinanceAdapter``    — wraps python-binance / ccxt
- ``_CsvAdapter``        — reads OHLCV from local CSV files
- ``_SyntheticAdapter``  — deterministic synthetic fallback (no deps)

Integration
-----------
SystemFactory injects broker dependencies at boot; DataRouter also
works as a zero-argument singleton for research and backtest pipelines.
"""

from __future__ import annotations

import csv
import hashlib
import logging
import math
import os
import random
import threading
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

Candle = Dict[str, Any]   # {ts, open, high, low, close, volume}
Quote  = Dict[str, Any]   # {symbol, bid, ask, last, volume, ts}


# ---------------------------------------------------------------------------
# Adapter base / protocol
# ---------------------------------------------------------------------------

class _FeedAdapter:
    """Abstract base for all feed adapters.

    Concrete subclasses override one or more methods.  Default
    implementations return empty / null results so callers never crash.
    """

    name: str = "base"

    # ------------------------------------------------------------------
    def get_candles(self, symbol: str, timeframe: str = "5m") -> List[Candle]:
        return []

    def get_quote(self, symbol: str) -> Optional[Quote]:
        return None

    def subscribe(self, symbol: str) -> None:
        pass

    def historical(
        self,
        symbol: str,
        start: datetime,
        end: datetime,
        timeframe: str = "1d",
    ) -> List[Candle]:
        return []

    # ------------------------------------------------------------------
    @staticmethod
    def _ts_now() -> str:
        return datetime.now(tz=timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Synthetic adapter — deterministic fallback, no external deps
# ---------------------------------------------------------------------------

class _SyntheticAdapter(_FeedAdapter):
    """Generates reproducible OHLCV candles from a seeded random walk.

    The seed is derived from the symbol name so the same symbol always
    produces the same price series, making backtests repeatable.
    No file I/O, no network calls.
    """

    name = "synthetic"

    _TIMEFRAME_MINUTES: Dict[str, int] = {
        "1m": 1, "3m": 3, "5m": 5, "10m": 10, "15m": 15,
        "30m": 30, "1h": 60, "2h": 120, "4h": 240,
        "1d": 1440, "1w": 10080,
    }
    _DEFAULT_CANDLES = 500

    def __init__(self, default_price: float = 100.0, volatility: float = 0.012) -> None:
        self._base_price   = default_price
        self._volatility   = volatility
        self._cache: Dict[str, List[Candle]] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ helpers
    def _seed(self, symbol: str) -> int:
        return int(hashlib.md5(symbol.encode()).hexdigest(), 16) % (2**32)

    def _build_series(
        self,
        symbol: str,
        n: int,
        end: Optional[datetime] = None,
        tf_minutes: int = 5,
    ) -> List[Candle]:
        rng   = random.Random(self._seed(symbol))
        price = self._base_price
        end   = end or datetime.now(tz=timezone.utc)
        candles: List[Candle] = []
        for i in range(n):
            ts    = end - timedelta(minutes=tf_minutes * (n - i))
            pct   = rng.gauss(0.0, self._volatility)
            close = round(max(price * (1 + pct), 0.01), 4)
            high  = round(max(price, close) * (1 + abs(rng.gauss(0, 0.003))), 4)
            low   = round(min(price, close) * (1 - abs(rng.gauss(0, 0.003))), 4)
            open_ = round(price * (1 + rng.gauss(0, 0.002)), 4)
            vol   = int(abs(rng.gauss(100_000, 30_000)))
            candles.append({
                "ts":     ts.isoformat(),
                "open":   open_,
                "high":   high,
                "low":    low,
                "close":  close,
                "volume": vol,
            })
            price = close
        return candles

    # ------------------------------------------------------------------ public
    def get_candles(self, symbol: str, timeframe: str = "5m") -> List[Candle]:
        tf_min = self._TIMEFRAME_MINUTES.get(timeframe, 5)
        key    = f"{symbol}:{timeframe}"
        with self._lock:
            if key not in self._cache:
                self._cache[key] = self._build_series(
                    symbol, self._DEFAULT_CANDLES, tf_minutes=tf_min
                )
            return list(self._cache[key])

    def get_quote(self, symbol: str) -> Quote:
        candles = self.get_candles(symbol)
        last    = candles[-1]["close"] if candles else self._base_price
        spread  = round(last * 0.0001, 4)
        return {
            "symbol": symbol,
            "bid":    round(last - spread, 4),
            "ask":    round(last + spread, 4),
            "last":   last,
            "volume": candles[-1]["volume"] if candles else 0,
            "ts":     self._ts_now(),
        }

    def subscribe(self, symbol: str) -> None:
        logger.debug("SyntheticAdapter.subscribe: %s (no-op)", symbol)

    def historical(
        self,
        symbol: str,
        start: datetime,
        end: datetime,
        timeframe: str = "1d",
    ) -> List[Candle]:
        if start >= end:
            return []
        tf_min  = self._TIMEFRAME_MINUTES.get(timeframe, 1440)
        delta   = int((end - start).total_seconds() / 60)
        n_bars  = max(1, delta // tf_min)
        series  = self._build_series(symbol, n_bars, end=end, tf_minutes=tf_min)
        return [c for c in series if start.isoformat() <= c["ts"] <= end.isoformat()]


# ---------------------------------------------------------------------------
# CSV adapter
# ---------------------------------------------------------------------------

class _CsvAdapter(_FeedAdapter):
    """Reads OHLCV data from local CSV files.

    Expected CSV format (header required)::

        timestamp,open,high,low,close,volume

    Directory layout::

        <csv_dir>/<SYMBOL>.csv          (e.g.  NSE:INFY.csv)
        <csv_dir>/<SYMBOL>_<TF>.csv     (e.g.  NSE:INFY_5m.csv)

    Colons in symbols are replaced with underscores for filenames.
    """

    name = "csv"

    def __init__(self, csv_dir: str = "data/csv") -> None:
        self._dir   = csv_dir
        self._cache: Dict[str, List[Candle]] = {}
        self._lock  = threading.Lock()

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _safe_name(symbol: str) -> str:
        return symbol.replace(":", "_").replace("/", "_")

    def _filepath(self, symbol: str, timeframe: str) -> Optional[str]:
        base = self._safe_name(symbol)
        candidates = [
            os.path.join(self._dir, f"{base}_{timeframe}.csv"),
            os.path.join(self._dir, f"{base}.csv"),
        ]
        for path in candidates:
            if os.path.isfile(path):
                return path
        return None

    def _load(self, symbol: str, timeframe: str) -> List[Candle]:
        path = self._filepath(symbol, timeframe)
        if path is None:
            return []
        try:
            candles: List[Candle] = []
            with open(path, newline="", encoding="utf-8") as fh:
                reader = csv.DictReader(fh)
                for row in reader:
                    try:
                        candles.append({
                            "ts":     row.get("timestamp", row.get("ts", "")),
                            "open":   float(row.get("open",   0)),
                            "high":   float(row.get("high",   0)),
                            "low":    float(row.get("low",    0)),
                            "close":  float(row.get("close",  0)),
                            "volume": int(float(row.get("volume", 0))),
                        })
                    except (ValueError, KeyError):
                        continue
            logger.info("CsvAdapter: loaded %d candles from %s", len(candles), path)
            return candles
        except OSError as exc:
            logger.warning("CsvAdapter: cannot read %s — %s", path, exc)
            return []

    # ------------------------------------------------------------------ public
    def get_candles(self, symbol: str, timeframe: str = "5m") -> List[Candle]:
        key = f"{symbol}:{timeframe}"
        with self._lock:
            if key not in self._cache:
                self._cache[key] = self._load(symbol, timeframe)
            return list(self._cache[key])

    def get_quote(self, symbol: str) -> Optional[Quote]:
        candles = self.get_candles(symbol)
        if not candles:
            return None
        last = candles[-1]["close"]
        return {
            "symbol": symbol,
            "bid":    round(last * 0.9999, 4),
            "ask":    round(last * 1.0001, 4),
            "last":   last,
            "volume": candles[-1]["volume"],
            "ts":     candles[-1]["ts"],
        }

    def historical(
        self,
        symbol: str,
        start: datetime,
        end: datetime,
        timeframe: str = "1d",
    ) -> List[Candle]:
        all_candles = self.get_candles(symbol, timeframe)
        s, e = start.isoformat(), end.isoformat()
        return [c for c in all_candles if s <= c["ts"] <= e]


# ---------------------------------------------------------------------------
# Fyers adapter (lazy import)
# ---------------------------------------------------------------------------

class _FyersAdapter(_FeedAdapter):
    """Wraps :class:`quant_ecosystem.broker.fyers_broker.FyersBroker`.

    Lazy-imports the broker module at first use.
    """

    name = "fyers"

    _TF_MAP: Dict[str, str] = {
        "1m": "1", "3m": "3", "5m": "5", "10m": "10", "15m": "15",
        "30m": "30", "1h": "60", "2h": "120", "4h": "240",
        "1d": "D", "1w": "W",
    }

    def __init__(self, broker=None, config=None) -> None:
        self._broker = broker
        self._config = config
        self._connected = False

    def _ensure_broker(self) -> bool:
        if self._broker is not None and self._connected:
            return True
        try:
            if self._broker is None:
                from quant_ecosystem.broker.fyers_broker import FyersBroker  # noqa: lazy
                self._broker = FyersBroker(config=self._config)
            self._broker.connect()
            self._connected = getattr(self._broker, "connected", False)
        except Exception as exc:
            logger.debug("FyersAdapter._ensure_broker: %s", exc)
            self._connected = False
        return self._connected

    def get_candles(self, symbol: str, timeframe: str = "5m") -> List[Candle]:
        if not self._ensure_broker():
            return []
        resolution = self._TF_MAP.get(timeframe, "5")
        try:
            feed = getattr(self._broker, "_feed", None)
            if feed is None:
                from quant_ecosystem.market.fyers_feed import FyersFeed  # noqa: lazy
                feed = FyersFeed(self._broker)
            raw = feed.get_candles(symbol, resolution)
            return self._normalize(raw)
        except Exception as exc:
            logger.debug("FyersAdapter.get_candles(%s): %s", symbol, exc)
            return []

    def get_quote(self, symbol: str) -> Optional[Quote]:
        if not self._ensure_broker():
            return None
        try:
            raw = self._broker.get_ltp(symbol)
            return {
                "symbol": symbol,
                "bid":    float(raw.get("bid", raw.get("lp", 0))),
                "ask":    float(raw.get("ask", raw.get("lp", 0))),
                "last":   float(raw.get("lp",  raw.get("last_price", 0))),
                "volume": int(raw.get("volume", 0)),
                "ts":     self._ts_now(),
            }
        except Exception as exc:
            logger.debug("FyersAdapter.get_quote(%s): %s", symbol, exc)
            return None

    def subscribe(self, symbol: str) -> None:
        if not self._ensure_broker():
            return
        try:
            if hasattr(self._broker, "subscribe"):
                self._broker.subscribe(symbol)
        except Exception as exc:
            logger.debug("FyersAdapter.subscribe(%s): %s", symbol, exc)

    def historical(
        self,
        symbol: str,
        start: datetime,
        end: datetime,
        timeframe: str = "1d",
    ) -> List[Candle]:
        if not self._ensure_broker():
            return []
        resolution = self._TF_MAP.get(timeframe, "D")
        try:
            payload = {
                "symbol":     symbol,
                "resolution": resolution,
                "date_format": "1",
                "range_from": start.strftime("%Y-%m-%d"),
                "range_to":   end.strftime("%Y-%m-%d"),
                "cont_flag":  "1",
            }
            live   = getattr(self._broker, "live_client", None)
            client = getattr(live, "client", live)
            if client and hasattr(client, "history"):
                raw = client.history(payload)
            elif hasattr(self._broker, "history"):
                raw = self._broker.history(payload)
            else:
                return []
            return self._normalize(raw)
        except Exception as exc:
            logger.debug("FyersAdapter.historical(%s): %s", symbol, exc)
            return []

    @staticmethod
    def _normalize(raw: Any) -> List[Candle]:
        if raw is None:
            return []
        candles_raw = raw.get("candles", raw) if isinstance(raw, dict) else raw
        if not isinstance(candles_raw, list):
            return []
        out: List[Candle] = []
        for row in candles_raw:
            try:
                if isinstance(row, (list, tuple)) and len(row) >= 6:
                    ts = datetime.fromtimestamp(row[0], tz=timezone.utc).isoformat() if isinstance(row[0], (int, float)) else str(row[0])
                    out.append({"ts": ts, "open": float(row[1]), "high": float(row[2]), "low": float(row[3]), "close": float(row[4]), "volume": int(row[5])})
                elif isinstance(row, dict):
                    out.append({"ts": str(row.get("ts", row.get("timestamp", ""))), "open": float(row.get("open", 0)), "high": float(row.get("high", 0)), "low": float(row.get("low", 0)), "close": float(row.get("close", 0)), "volume": int(row.get("volume", 0))})
            except (ValueError, IndexError, TypeError):
                continue
        return out


# ---------------------------------------------------------------------------
# Zerodha adapter (lazy import)
# ---------------------------------------------------------------------------

class _ZerodhaAdapter(_FeedAdapter):
    """Wraps kiteconnect.KiteConnect for Zerodha market data.

    Lazy-imports ``kiteconnect`` at first use; degrades gracefully if
    the package is not installed or credentials are not set.
    """

    name = "zerodha"

    _TF_MAP: Dict[str, str] = {
        "1m": "minute", "3m": "3minute", "5m": "5minute",
        "10m": "10minute", "15m": "15minute", "30m": "30minute",
        "1h": "60minute", "1d": "day", "1w": "week",
    }

    def __init__(
        self,
        api_key: Optional[str] = None,
        access_token: Optional[str] = None,
    ) -> None:
        self._api_key      = api_key      or os.getenv("ZERODHA_API_KEY",      "")
        self._access_token = access_token or os.getenv("ZERODHA_ACCESS_TOKEN", "")
        self._kite = None

    def _ensure_kite(self) -> bool:
        if self._kite is not None:
            return True
        if not (self._api_key and self._access_token):
            return False
        try:
            from kiteconnect import KiteConnect  # noqa: lazy
            self._kite = KiteConnect(api_key=self._api_key)
            self._kite.set_access_token(self._access_token)
        except Exception as exc:
            logger.debug("ZerodhaAdapter._ensure_kite: %s", exc)
            return False
        return True

    def get_candles(self, symbol: str, timeframe: str = "5m") -> List[Candle]:
        if not self._ensure_kite():
            return []
        interval = self._TF_MAP.get(timeframe, "5minute")
        try:
            token = self._resolve_token(symbol)
            from datetime import date
            today = date.today()
            raw = self._kite.historical_data(token, today, today, interval)
            return [{"ts": str(r["date"]), "open": r["open"], "high": r["high"], "low": r["low"], "close": r["close"], "volume": r.get("volume", 0)} for r in raw]
        except Exception as exc:
            logger.debug("ZerodhaAdapter.get_candles(%s): %s", symbol, exc)
            return []

    def get_quote(self, symbol: str) -> Optional[Quote]:
        if not self._ensure_kite():
            return None
        try:
            raw = self._kite.ltp([symbol])
            data = raw.get(symbol, {})
            last = data.get("last_price", 0.0)
            return {"symbol": symbol, "bid": last, "ask": last, "last": last, "volume": 0, "ts": self._ts_now()}
        except Exception as exc:
            logger.debug("ZerodhaAdapter.get_quote(%s): %s", symbol, exc)
            return None

    def subscribe(self, symbol: str) -> None:
        logger.debug("ZerodhaAdapter.subscribe: %s (WebSocket not implemented here)", symbol)

    def historical(
        self,
        symbol: str,
        start: datetime,
        end: datetime,
        timeframe: str = "1d",
    ) -> List[Candle]:
        if not self._ensure_kite():
            return []
        interval = self._TF_MAP.get(timeframe, "day")
        try:
            token = self._resolve_token(symbol)
            raw   = self._kite.historical_data(token, start.date(), end.date(), interval)
            return [{"ts": str(r["date"]), "open": r["open"], "high": r["high"], "low": r["low"], "close": r["close"], "volume": r.get("volume", 0)} for r in raw]
        except Exception as exc:
            logger.debug("ZerodhaAdapter.historical(%s): %s", symbol, exc)
            return []

    def _resolve_token(self, symbol: str) -> int:
        """Minimal token resolution — subclass or extend for full instrument lookup."""
        try:
            instruments = self._kite.instruments("NSE")
            for inst in instruments:
                if inst.get("tradingsymbol") == symbol.split(":")[-1]:
                    return inst["instrument_token"]
        except Exception:
            pass
        raise ValueError(f"ZerodhaAdapter: cannot resolve token for {symbol!r}")


# ---------------------------------------------------------------------------
# Binance adapter (lazy import)
# ---------------------------------------------------------------------------

class _BinanceAdapter(_FeedAdapter):
    """Wraps python-binance or ccxt for crypto market data.

    Tries python-binance first; falls back to ccxt if not installed.
    """

    name = "binance"

    _TF_MAP: Dict[str, str] = {
        "1m": "1m", "3m": "3m", "5m": "5m", "15m": "15m", "30m": "30m",
        "1h": "1h", "2h": "2h", "4h": "4h", "6h": "6h", "12h": "12h",
        "1d": "1d", "3d": "3d", "1w": "1w",
    }
    _CCXT_TF: Dict[str, str] = {
        "1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m",
        "1h": "1h", "4h": "4h", "1d": "1d",
    }

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
    ) -> None:
        self._api_key    = api_key    or os.getenv("BINANCE_API_KEY",    "")
        self._api_secret = api_secret or os.getenv("BINANCE_API_SECRET", "")
        self._client = None
        self._ccxt   = None

    @staticmethod
    def _clean_symbol(symbol: str) -> str:
        """Strip exchange prefix: ``CRYPTO:BTCUSDT`` → ``BTCUSDT``."""
        return symbol.split(":")[-1].replace("-", "").replace("/", "")

    def _ensure_client(self) -> bool:
        if self._client is not None or self._ccxt is not None:
            return True
        # Try python-binance
        try:
            from binance.client import Client  # noqa: lazy
            self._client = Client(self._api_key, self._api_secret)
            return True
        except Exception:
            pass
        # Try ccxt
        try:
            import ccxt  # noqa: lazy
            self._ccxt = ccxt.binance({
                "apiKey": self._api_key,
                "secret": self._api_secret,
                "enableRateLimit": True,
            })
            return True
        except Exception as exc:
            logger.debug("BinanceAdapter._ensure_client: %s", exc)
            return False

    def get_candles(self, symbol: str, timeframe: str = "5m") -> List[Candle]:
        if not self._ensure_client():
            return []
        sym = self._clean_symbol(symbol)
        try:
            if self._client:
                interval = self._TF_MAP.get(timeframe, "5m")
                raw = self._client.get_klines(symbol=sym, interval=interval, limit=500)
                return [{"ts": datetime.fromtimestamp(r[0]/1000, tz=timezone.utc).isoformat(), "open": float(r[1]), "high": float(r[2]), "low": float(r[3]), "close": float(r[4]), "volume": float(r[5])} for r in raw]
            else:
                interval = self._CCXT_TF.get(timeframe, "5m")
                raw = self._ccxt.fetch_ohlcv(sym, interval, limit=500)
                return [{"ts": datetime.fromtimestamp(r[0]/1000, tz=timezone.utc).isoformat(), "open": r[1], "high": r[2], "low": r[3], "close": r[4], "volume": r[5]} for r in raw]
        except Exception as exc:
            logger.debug("BinanceAdapter.get_candles(%s): %s", symbol, exc)
            return []

    def get_quote(self, symbol: str) -> Optional[Quote]:
        if not self._ensure_client():
            return None
        sym = self._clean_symbol(symbol)
        try:
            if self._client:
                ticker = self._client.get_symbol_ticker(symbol=sym)
                last   = float(ticker["price"])
            else:
                ticker = self._ccxt.fetch_ticker(sym)
                last   = float(ticker["last"])
            return {"symbol": symbol, "bid": last, "ask": last, "last": last, "volume": 0, "ts": self._ts_now()}
        except Exception as exc:
            logger.debug("BinanceAdapter.get_quote(%s): %s", symbol, exc)
            return None

    def subscribe(self, symbol: str) -> None:
        logger.debug("BinanceAdapter.subscribe: %s (WebSocket not implemented here)", symbol)

    def historical(
        self,
        symbol: str,
        start: datetime,
        end: datetime,
        timeframe: str = "1d",
    ) -> List[Candle]:
        if not self._ensure_client():
            return []
        sym = self._clean_symbol(symbol)
        try:
            if self._client:
                interval  = self._TF_MAP.get(timeframe, "1d")
                start_ms  = int(start.timestamp() * 1000)
                end_ms    = int(end.timestamp()   * 1000)
                raw = self._client.get_historical_klines(sym, interval, start_ms, end_ms)
                return [{"ts": datetime.fromtimestamp(r[0]/1000, tz=timezone.utc).isoformat(), "open": float(r[1]), "high": float(r[2]), "low": float(r[3]), "close": float(r[4]), "volume": float(r[5])} for r in raw]
            else:
                interval = self._CCXT_TF.get(timeframe, "1d")
                since    = int(start.timestamp() * 1000)
                raw = self._ccxt.fetch_ohlcv(sym, interval, since=since, limit=1000)
                end_ts = end.isoformat()
                return [{"ts": datetime.fromtimestamp(r[0]/1000, tz=timezone.utc).isoformat(), "open": r[1], "high": r[2], "low": r[3], "close": r[4], "volume": r[5]} for r in raw if datetime.fromtimestamp(r[0]/1000, tz=timezone.utc).isoformat() <= end_ts]
        except Exception as exc:
            logger.debug("BinanceAdapter.historical(%s): %s", symbol, exc)
            return []


# ---------------------------------------------------------------------------
# DataRouter — main public class
# ---------------------------------------------------------------------------

class DataRouter:
    """Unified market-data router for the Quant Ecosystem.

    Holds an ordered adapter chain; each call walks the chain until one
    adapter returns a non-empty result.  The final entry is always
    :class:`_SyntheticAdapter`, guaranteeing the system never returns
    empty data in PAPER/research mode.

    Parameters
    ----------
    mode:
        ``"LIVE"`` enables real broker adapters; ``"PAPER"`` / ``"RESEARCH"``
        skips broker adapters and goes straight to CSV / synthetic.
    fyers_broker:
        Injected :class:`FyersBroker` instance (optional).
    zerodha_api_key / zerodha_access_token:
        Credentials for KiteConnect (optional).
    binance_api_key / binance_api_secret:
        Credentials for python-binance / ccxt (optional).
    csv_dir:
        Directory containing CSV files for :class:`_CsvAdapter` (optional).
    extra_adapters:
        Additional :class:`_FeedAdapter` instances to prepend to the chain.

    Example
    -------
    >>> router = DataRouter()                     # synthetic-only (PAPER)
    >>> candles = router.get_candles("NSE:INFY", "5m")
    >>> quote   = router.get_quote("NSE:INFY")
    >>> hist    = router.historical("NSE:INFY",
    ...               start=datetime(2025, 1, 1, tzinfo=timezone.utc),
    ...               end=datetime(2025, 3, 1,   tzinfo=timezone.utc))
    """

    def __init__(
        self,
        mode: str = "PAPER",
        fyers_broker=None,
        zerodha_api_key: Optional[str] = None,
        zerodha_access_token: Optional[str] = None,
        binance_api_key: Optional[str] = None,
        binance_api_secret: Optional[str] = None,
        csv_dir: Optional[str] = None,
        extra_adapters: Optional[List[_FeedAdapter]] = None,
    ) -> None:
        self._mode      = mode.upper()
        self._adapters: List[_FeedAdapter] = []
        self._lock      = threading.Lock()
        self._subscribers: Dict[str, List[Callable]] = {}

        # ---- build adapter chain ----------------------------------------
        if extra_adapters:
            self._adapters.extend(extra_adapters)

        if self._mode == "LIVE":
            if fyers_broker is not None:
                self._adapters.append(_FyersAdapter(broker=fyers_broker))
            if zerodha_api_key:
                self._adapters.append(
                    _ZerodhaAdapter(zerodha_api_key, zerodha_access_token)
                )
            if binance_api_key:
                self._adapters.append(
                    _BinanceAdapter(binance_api_key, binance_api_secret)
                )

        if csv_dir:
            self._adapters.append(_CsvAdapter(csv_dir=csv_dir))

        # Synthetic is always the last resort
        self._adapters.append(_SyntheticAdapter())

        logger.info(
            "DataRouter initialized (mode=%s, adapters=[%s])",
            self._mode,
            ", ".join(a.name for a in self._adapters),
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_candles(self, symbol: str, timeframe: str = "5m") -> List[Candle]:
        """Return the latest OHLCV candle list for *symbol* / *timeframe*.

        Walks the adapter chain; returns the first non-empty result.
        """
        for adapter in self._adapters:
            try:
                result = adapter.get_candles(symbol, timeframe)
                if result:
                    return result
            except Exception as exc:
                logger.debug("DataRouter.get_candles[%s](%s): %s", adapter.name, symbol, exc)
        return []

    def get_quote(self, symbol: str) -> Optional[Quote]:
        """Return the latest bid/ask/last quote for *symbol*.

        Walks the adapter chain; returns the first non-None result.
        """
        for adapter in self._adapters:
            try:
                result = adapter.get_quote(symbol)
                if result is not None:
                    return result
            except Exception as exc:
                logger.debug("DataRouter.get_quote[%s](%s): %s", adapter.name, symbol, exc)
        return None

    def subscribe(self, symbol: str, callback: Optional[Callable] = None) -> None:
        """Subscribe to live tick updates for *symbol*.

        *callback* (if provided) will be called with each new tick dict
        when the underlying feed supports streaming.  In PAPER mode this
        is a no-op.
        """
        with self._lock:
            if callback:
                self._subscribers.setdefault(symbol, []).append(callback)
        for adapter in self._adapters:
            try:
                adapter.subscribe(symbol)
            except Exception as exc:
                logger.debug("DataRouter.subscribe[%s](%s): %s", adapter.name, symbol, exc)

    def historical(
        self,
        symbol: str,
        start: datetime,
        end: Optional[datetime] = None,
        timeframe: str = "1d",
    ) -> List[Candle]:
        """Return historical OHLCV candles between *start* and *end*.

        Parameters
        ----------
        symbol:    Instrument identifier (e.g. ``"NSE:INFY"``).
        start:     Range start (tz-aware recommended).
        end:       Range end; defaults to *now* when omitted.
        timeframe: Bar interval string (``"1m"``, ``"5m"``, ``"1d"`` …).
        """
        end = end or datetime.now(tz=timezone.utc)
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)
        for adapter in self._adapters:
            try:
                result = adapter.historical(symbol, start, end, timeframe)
                if result:
                    return result
            except Exception as exc:
                logger.debug("DataRouter.historical[%s](%s): %s", adapter.name, symbol, exc)
        return []

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def close_series(self, symbol: str, timeframe: str = "5m") -> List[float]:
        """Return a plain list of close prices for *symbol*."""
        return [c["close"] for c in self.get_candles(symbol, timeframe)]

    def register_adapter(self, adapter: _FeedAdapter, *, prepend: bool = False) -> None:
        """Add a custom adapter to the chain at runtime.

        Parameters
        ----------
        adapter: Adapter instance implementing :class:`_FeedAdapter`.
        prepend: Insert at the *front* of the chain (highest priority).
        """
        if prepend:
            self._adapters.insert(0, adapter)
        else:
            # Insert before the synthetic fallback (always last)
            self._adapters.insert(max(0, len(self._adapters) - 1), adapter)
        logger.info("DataRouter: registered adapter '%s' (prepend=%s)", adapter.name, prepend)

    def adapter_names(self) -> List[str]:
        """Return names of all active adapters in chain order."""
        return [a.name for a in self._adapters]

    def set_mode(self, mode: str) -> None:
        """Switch routing mode at runtime (``"LIVE"`` / ``"PAPER"``)."""
        self._mode = mode.upper()
        logger.info("DataRouter: mode set to %s", self._mode)

    def __repr__(self) -> str:
        return (
            f"DataRouter(mode={self._mode!r}, "
            f"adapters={self.adapter_names()})"
        )
